package vcs;

public class Commit {
}
